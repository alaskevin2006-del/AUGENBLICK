Upload this ZIP as a draft course. Samples are original test content, not a professional teaching corpus. Companion uses synthetic tones for technical validation, not pronunciation teaching.
See repository engine documentation for authoring instructions.
